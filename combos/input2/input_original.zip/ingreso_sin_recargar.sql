CREATE TABLE `ingreso_db` (
  `id` varchar(40) NOT NULL default '0',
  `valor` varchar(40) NOT NULL
) ENGINE=MyISAM;


INSERT INTO `ingreso_db` (`id`, `valor`) VALUES ('campo1', 'Dato1'),
('campo2', 'Dato2');